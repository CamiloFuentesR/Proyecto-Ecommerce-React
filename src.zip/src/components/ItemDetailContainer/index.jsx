import { ItemDetail } from "../ItemDetail"
import { useEffect, useState } from "react"
import { useParams } from 'react-router-dom';

const productosJson = [{
    id: 1,
    availableStock: 5,
    name: "Zapatilla Mujer",
    price: "30.000",
    image: "zapatilla.jpeg",
    description: "Zapatilla Mujer Adidas blanca",
    categoryId: "Mujer",
  },{
    id: 2,
    availableStock: 5,
    name: "Zapatilla Mujer",
    price: "30.000",
    image: "zapatilla.jpeg",
    description: "Zapatilla Mujer Adidas negra",
    categoryId: "Mujer",
  },{
    id: 3,
    availableStock: 5,
    name: "Polerón Hombre",
    price: "20.000",
    image: "poleron.jpg",
    description: "Polerón Los Simpsons",
    categoryId: "Hombre",
  },{
    id: 4,
    availableStock: 5,
    name: "Polerón Hombre",
    price: "15.000",
    image: "poleron.jpg",
    description: "Polerón rick and Morty",
    categoryId: "Hombre",
  },{
    id: 5,
    availableStock: 5,
    name: "Mochila Kids",
    price: "15.000",
    image: "mochila.jpeg",
    description: "Mochila monster Inc",
    categoryId: "Niños/Niñas",
  },{
    id: 6,
    availableStock: 5,
    name: "Mochila Kids",
    price: "15.000",
    image: "mochila.jpeg",
    description: "Mochila Wall-e",
    categoryId: "Niños/Niñas",
  },{
    id: 7,
    availableStock: 5,
    name: "Mochila Kids",
    price: "15.000",
    image: "mochila.jpeg",
    description: "Mochila Toy Story",
    categoryId: "Niños/Niñas",
  },{
    id: 8,
    availableStock: 5,
    name: "Mochila Kids",
    price: "15.000",
    image: "mochila.jpeg",
    description: "Mochila Nemo",
    categoryId: "Niños/Niñas",
  }
  ]

export const ItemDetailContainer = () => {
    const[productosMock, setProductosMock] = useState();
    const {id} = useParams();

    useEffect(() => {
        const misProductos = new Promise((resolve) =>{
            resolve(productosJson);
        })
        
        if(id){
            misProductos.then(data => {
            const productoId = data.find(element => element.id === parseInt(id))
            setProductosMock(productoId)
            })
        }

        // async function productos(){
        //     const response = await fetch(`https://api.mercadolibre.com/sites/MLC/search?q=tecnologia`);
        //     const data = await response.json();
        //     setProductosMock (data.results[5]);
        // }
        // setTimeout(() =>{
        //     productos()
        // },1000);

    }, [id])
    console.log(productosMock)
    
    return(
        <>
        {productosMock ?
        <ItemDetail key={productosMock.id} stock={productosMock.availableStock} nombre={productosMock.name} precio={productosMock.price} imagen={productosMock.image} descripcion={productosMock.description} categoria={productosMock.categoryId}/>
        : <p>Cargando...</p>}
        </>
        )
    }
