export const probandoEnConsola = (mensaje) => {
    console.log(mensaje)
}

export const saludoBotonAgregar = (mensaje) => {
    alert(mensaje)
}